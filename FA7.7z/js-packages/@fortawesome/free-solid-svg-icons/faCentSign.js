'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'cent-sign';
var width = 384;
var height = 512;
var aliases = [];
var unicode = 'e3f5';
var svgPathData = 'M208 0c17.7 0 32 14.3 32 32l0 25.4c43.6 5.2 83 24.5 113.3 53.1 12.9 12.1 13.4 32.4 1.3 45.2s-32.4 13.4-45.2 1.3c-24.4-23-57.2-37.1-93.3-37.1-75.1 0-136 60.9-136 136s60.9 136 136 136c36.2 0 69-14.1 93.3-37.1 12.9-12.1 33.1-11.5 45.2 1.3s11.5 33.1-1.3 45.2C323 430.1 283.6 449.4 240 454.6l0 25.4c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-28C84.7 433.5 16 352.8 16 256S84.7 78.5 176 60l0-28c0-17.7 14.3-32 32-32z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faCentSign = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;