'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'house-fire';
var width = 640;
var height = 512;
var aliases = [];
var unicode = 'e50c';
var svgPathData = 'M448 192c14.1 .4 23.8 11.4 32.7 21.7 2 2.3 4 4.6 6 6.7l19 19.9 12.2-13.8c5.4-6.1 13.3-8.9 20.9-8.9 7.2 0 14.3 2.6 19.9 7.8 19.7 18.3 39.8 43.2 55 70.6 15.1 27.2 26.2 58.2 26.2 88.2 0 88.7-71.3 159.8-160 159.8-89.6 0-160-71.3-160-159.8 0-37.3 16-73.4 36.8-104.5 20.9-31.3 47.5-59 70.9-80.1 5.7-5.2 13.1-7.7 20.3-7.5zM268.6 6.5c12.2-9.3 29.7-8.7 41.2 2l147.5 137c-19.2-4.3-40 .5-55.5 14.4-36.4 32.6-67.7 69.8-90.3 106.4-10.3 16.6-19.7 34.9-26.8 53.7L272 320c-26.5 0-48 21.5-48 48l0 96 64.6 0c7.3 17.2 16.8 33.4 28.2 48L144 512c-35.3 0-64-28.7-64-64l0-176-16 0c-13.2 0-25-8.1-29.8-20.3s-1.6-26.2 8-35.1l224-208 2.4-2zM489.3 343.7c-5.4-4.7-13.1-4.7-18.5 0-17.7 15.4-54.7 51.9-54.7 88.4 0 35.3 28.7 64 64 64s64-28.7 64-64c0-36.5-37-73-54.7-88.4z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faHouseFire = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;