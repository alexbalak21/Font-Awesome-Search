'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'book-journal-whills';
var width = 448;
var height = 512;
var aliases = ["journal-whills"];
var unicode = 'f66a';
var svgPathData = 'M96 512l320 0c17.7 0 32-14.3 32-32s-14.3-32-32-32l0-66.7c18.6-6.6 32-24.4 32-45.3l0-288c0-26.5-21.5-48-48-48L96 0C43 0 0 43 0 96L0 416c0 53 43 96 96 96zM64 416c0-17.7 14.3-32 32-32l256 0 0 64-256 0c-17.7 0-32-14.3-32-32zM274.1 99.2c2.6-2.6 6.7-3.1 9.9-1.1 32.1 20 53.4 55.6 53.4 96.2 0 62.6-50.7 113.3-113.3 113.3S110.7 256.9 110.7 194.3c0-40.6 21.4-76.2 53.4-96.2 3.1-2 7.2-1.5 9.9 1.1s3.1 6.7 1.2 9.8c-5.2 8.6-8.2 18.7-8.2 29.5 0 15.1 5.9 28.8 15.5 39.1 2.5 2.7 2.9 6.7 .9 9.7-4.7 7.4-7.4 16.1-7.4 25.5 0 21.6 14.3 39.9 34 45.9l1-24.8c-7.1-4.4-11.8-12.2-11.8-21.1 0-9.6 5.5-18 13.5-22.1l3.3-81.8c.2-4.3 3.7-7.7 8-7.7s7.8 3.4 8 7.7l3.3 81.8c8 4.1 13.5 12.4 13.5 22.1 0 8.9-4.7 16.7-11.8 21.1l1 24.8c19.6-6 33.9-24.1 34-45.6l0-.6c-.1-9.3-2.7-17.9-7.4-25.2-1.9-3.1-1.6-7.1 .9-9.7 9.6-10.2 15.5-23.9 15.5-39.1 0-10.8-3-20.9-8.2-29.5-1.9-3.2-1.4-7.2 1.2-9.8z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    aliases,
    unicode,
    svgPathData
  ]};

exports.faBookJournalWhills = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = aliases;
exports.unicode = unicode;
exports.svgPathData = svgPathData;
exports.aliases = aliases;